# Maintainers

Maintainership is on a per project basis. Reference [NATS Governance Model](https://github.com/nats-io/nats-general/blob/main/GOVERNANCE.md).

### Maintainers
  - Derek Collison <derek@nats.io> [@derekcollison](https://github.com/derekcollison)
  - Ivan Kozlovic <ivan@nats.io> [@kozlovic](https://github.com/kozlovic)
  - Waldemar Quevedo <wally@nats.io> [@wallyqs](https://github.com/wallyqs)
  - Oleg Shaldybin <olegsh@google.com> [@olegshaldybin](https://github.com/olegshaldybin)
  - R.I. Pienaar <rip@devco.net> [@ripienaar](https://github.com/ripienaar)
