---
title: 'Twitter Architecture 2022 vs. 2012'
description: "A look at how Twitter's architecture evolved over the past decade."
image: 'https://assets.bytebytego.com/diagrams/0392-twitter-architecture-2022-vs-2012.jpeg'
createdAt: '2024-03-13'
draft: false
categories:
  - real-world-case-studies
tags:
  - System Design
  - Scalability
---

![](https://assets.bytebytego.com/diagrams/0392-twitter-architecture-2022-vs-2012.jpeg)

What’s changed over the past 10 years?!
