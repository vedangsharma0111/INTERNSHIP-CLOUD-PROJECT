---
title: 'How it Works?'
description: 'Go deep into the internals of how things work with these visual guides ranging from OAuth2 to how the internet works.'
image: 'https://github.com/ByteByteGoHq/system-design-101/raw/main/images/oAuth2.jpg'
icon: '/icons/question-mark.png'
sort: 190
---

Learning how things work is a great way to understand the world around us. This collection of guides will help you understand how things work in the world of system design.
