# 参考文档

* `Dockerfile` 官方文档：https://docs.docker.com/engine/reference/builder/

* `Dockerfile` 最佳实践文档：https://docs.docker.com/develop/develop-images/dockerfile_best-practices/

* `Docker` 官方镜像 `Dockerfile`：https://github.com/docker-library/docs
